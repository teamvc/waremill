/* vim: set expandtab tabstop=4 shiftwidth=4: */
/**
 * Apply Chosen to Email Users select boxes.
 *
 */
jQuery(document).ready(function($) {
    $(".mailusers-select").chosen();
});

